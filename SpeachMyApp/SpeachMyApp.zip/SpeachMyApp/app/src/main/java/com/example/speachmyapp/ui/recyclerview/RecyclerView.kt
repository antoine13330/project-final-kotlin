package com.example.speachmyapp.ui.recyclerview

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.speachmyapp.databinding.FragmentRecyclerViewBinding


class RecyclerView : Fragment()  {
    // -- for view binding --
    private var _binding: FragmentRecyclerViewBinding? = null
        /* _binding props getter */
    private val binding get() = _binding!!

    private var listItemRecycler : ArrayList<ItemRecycler> =  ArrayList<ItemRecycler>();


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // -- for view binding --
        _binding = FragmentRecyclerViewBinding.inflate(inflater, container, false)
        val root: View = binding.root
        // ----------------------
        fillListItemRecycler(10);
        // -- setting event listeners --
        binding.compRecycler.setRecyclerListener {}
        // ------------------------------
        return root
    }


    private fun fillListItemRecycler(numberOfItems: Int) {
        for (i in 1..numberOfItems) {
            val Item = ItemRecycler()
            Item._id = i
            Item._name = "User"+i
            listItemRecycler.add(Item)
            println("\n\n\n\n\n"+Item._name)
        }

    }
}

