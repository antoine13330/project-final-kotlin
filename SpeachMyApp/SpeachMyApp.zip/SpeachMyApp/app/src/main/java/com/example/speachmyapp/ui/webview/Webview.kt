package com.example.speachmyapp.ui.webview

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView

import android.widget.Toast
import com.example.speachmyapp.R
import com.example.speachmyapp.databinding.FragmentWebviewBinding

import androidx.appcompat.app.AppCompatActivity

/**
 * A simple [Fragment] subclass.
 * Use the [Webview.newInstance] factory method to
 * create an instance of this fragment.
 */
class Webview : Fragment() {
    // -- for view binding --
    private var _binding: FragmentWebviewBinding? = null
    /* _binding props getter */
    private val binding get() = _binding!!


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // -- for view binding --
        _binding = FragmentWebviewBinding.inflate(inflater, container, false)
        val root: View = binding.root
        // ----------------------
        // -- set event listeners --
        binding.searchViewForWebView.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextChange(p0: String?): Boolean {
                TODO("Not yet implemented")
            }

            override fun onQueryTextSubmit(p0: String?): Boolean {
                TODO("Not yet implemented")
            }
        })

        return root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }
}